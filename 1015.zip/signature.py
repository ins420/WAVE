# signature.py

from Crypto.PublicKey import ECC
from Crypto.Signature import DSS
from Crypto.Hash import SHA256
from glob import glob
from binascii import unhexlify, hexlify
from function import inputs

import asn1tools
import pickle

asn_file = glob("asn1/dot2/*.asn")
encoder = asn1tools.compile_files(asn_file, "oer")


def generate_signature(tbs_data: dict, key: ECC.EccKey) -> bytes:
    tbs_data = SHA256.new(encoder.encode("ToBeSignedData", tbs_data))
    signature = DSS.new(key=key, mode="fips-186-3").sign(tbs_data)
    return signature


def verify_signature(tbs_data: dict, certificate: dict, signature: bytes) -> bool:
    cert_list = pickle.load(open("list_file/cert_list.pkl", "rb"))
    ca_cert = pickle.load(open(cert_list[certificate["issuer"][1].hex()], "rb"))
    tbs_cert = encoder.encode("ToBeSignedCertificate", certificate["toBeSigned"])
    hashed_ca_cert = SHA256.new(encoder.encode("Certificate", ca_cert)).hexdigest()
    hashed_tbs_cert = SHA256.new(tbs_cert).hexdigest()
    e = SHA256.new(unhexlify(hashed_tbs_cert + hashed_ca_cert)).hexdigest()

    r_public = ECC.EccPoint(curve="P-256", x=int(inputs(certificate)[0]), y=int(inputs(certificate)[1]))
    pca_public = ECC.EccPoint(curve="P-256", x=int(inputs(ca_cert)[0]), y=int(inputs(ca_cert)[1]))

    butterfly_public = ECC.EccKey(curve="P-256", point=(r_public * int(e, 16)) + pca_public)

    tbs_data = SHA256.new(encoder.encode("ToBeSignedData", tbs_data))

    try:
        DSS.new(key=butterfly_public, mode="fips-186-3").verify(tbs_data, signature)
        return True
    except ValueError:
        return False


if __name__ == "__main__":
    # #data = {'ToBeSignedData':1}  # encoding(oer)
    # data = {'payload': {'data': {'protocolVersion': 3, 'content': ('unsecuredData', b'\x00\x14%\x00\x10\xd8\\\x8ch<\x1a\xd2t\x805\xa4\xe8\xff\x88\x00\x00\x00\x00\x00p\x05\x00\x00~}\x07\xd0\x7f\x7f\xff\x00\x00\x0b\x80\xd8')}}, 'headerInfo': {'psid': 32, 'generationTime': 590515661239797}}
    # obu_key = ECC.import_key(open("cert_file/implicit_cert/obu1/key_1.pem", "rt").read())
    # result = generate_signature(data, obu_key)
    # print("Signature:", result)
    # print(hexlify(result).decode())
    # print(len(result))
    for i in range(1, 20, 1):
        cert = pickle.load(open("cert_file/implicit_cert/obu1/cert_"+str(i)+".pkl", "rb"))
        print(hexlify(encoder.encode("Certificate", cert)).decode())


    # print("Result:", verify_signature(data, cert, result))
